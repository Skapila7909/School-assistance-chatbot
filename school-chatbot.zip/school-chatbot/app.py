# app.py
from PIL import Image, ImageTk
from flask import Flask, request, jsonify, render_template_string
from datetime import datetime
import re

app = Flask(__name__)

# ======= Knowledge / Rule-based response database =======
KB = {
    "adaptive_greeting": {
        "prompt": ["hi", "hello", "hey", "good morning", "good evening", "good afternoon"],
        "reply": lambda: (
            "Good morning!" if 0 <= datetime.now().hour < 12
            else "Good afternoon!" if 12 <= datetime.now().hour < 17
            else "Good evening!"
        )
    },
    "timings": {
        "prompt": ["timing", "hours", "when open", "open", "close", "schedule", "time"],
        "reply": "School hours: Monday–Saturday, 8:00 AM — 2:00 PM. No entry allowed after 8:00AM. 2nd and 4th Saturdays are non instructional. Primary classes end at 1:40PM"
    },
    "fees": {
        "prompt": ["fee", "fees", "tuition", "cost", "price"],
        "reply": "Current fees : Annual tuition ₹55,000, uniform and books not included.TnC apply. Transport extra based on route. Activity fees ₹2,00 per term. for more info: call XXXXXXXXXX"
    },
    "discounts": {
        "prompt": ["discount", "scholarship", "sibling", " concession", "rebate"],
        "reply": "We offer a 10% sibling discount, and a 5% early-payment discount on tuition if paid before April 30 each year.for class 11 students, 10 % discount if student has score 90 percent or above in class 10 CBSE exams and 15% discount on tuition if student scored above 95% in class 10 CBSE exams. for more informatio call XXXXXXXXXX" 
    },
    "policies": {
        "prompt": ["policy", "policies", "rules", "attendance policy", "discipline"],
        "reply": "Key policies: 80% minimum attendance to sit exams,properr uniform required , mobile phones restricted on campus, strict anti-bullying rules."
    },
    "payment": {
        "prompt": ["payment", "pay", "mode", "transaction", "upi", "bank transfer", "online"],
        "reply": "Payments accepted: UPI, netbanking (NEFT/IMPS), credit/debit cards at the office, and cheque. We provide digital invoices on request."
    },
    "history": {
        "prompt": ["history", "founded", "established", "about us", "about"],
        "reply": "Our school was founded in 1998 with a focus on holistic education and community engagement."
    },
    "attendance": {
        "prompt": ["attendance", "absent", "leave", "attendance rule", "required attendance"],
        "reply": "Students should maintain at least 80% attendance. Submit leave requests via the parent portal or written note to the class teacher."
    },
    "extracurriculars": {
        "prompt": ["extra", "extracurricular", "activities", "clubs", "sports", "music", "dance", "robotics"],
        "reply": "Extra-curriculars: football, basketball, music, dance, art, coding club, robotics and debate. We host a variety of intra school and interschool "
    },
    "syllabus": {
        "prompt": ["syllabus", "curriculum", "cbse", "board", "what we teach"],
        "reply": "We follow the CBSE curriculum with additional life-skills and project-based learning modules."
    },
    "exam_schedule": {
        "prompt": ["exam", "exam schedule", "test", "datesheet", "date sheet", "finals", "midterm"],
        "reply": "Exam schedules are published term-wise in the parent portal and on the notice board. Example: Term 1 exams: Oct 5–10; Term 2 exams: Feb 12–18 (example)."
    },
    "staff": {
        "prompt": ["staff", "teachers", "principal", "head", "teacher info", "faculty"],
        "reply": "We have over 50  teaching staff and 15 support staff. All teachers are certified with average 6+ years teaching experience. Contact details are available on request."
    },
    "amenities": {
        "prompt": ["amenity", "facility", "facilities", "labs", "library", "playground", "bus"],
        "reply": "Facilities: Smart classrooms, Physics,Chemistry,Biology & computer labs, library, playground, art studio, and music room "
    },
    "history_of_payments": {
        "prompt": ["history", "payment history", "fee history", "invoices", "receipts"],
        "reply": "Parents can view payment history and download receipts from the parent portal under 'Payments'."
    },
    "admission": {
        "prompt": ["admission", "enroll", "registration", "apply", "how to join"],
        "reply": "Admissions: Fill the online application on our admission page, submit required documents and pay the registration fee. Interview and assessment dates are shared later."
    },
    "transport": {
        "prompt": ["transport", "bus", "bus routes", "pickup", "drop"],
        "reply": "School transport: multiple bus routes with GPS tracking; pick-up times vary by route. Contact transport coordinator for route availability and charges."
    },
    "safety": {
        "prompt": ["safety", "security", "covid", "sanitation", "first aid"],
        "reply": "Safety: CCTV coverage, trained first-aid staff, regular fire drills, and strict visitor check-in procedures."
    },
    "default": {
        "prompt": [],
        "reply": "Sorry, I didn't get that. You can ask about timings, fees, discounts, admissions, transport, exams, staff, facilities, or say 'help' for suggested prompts."
    }
}

# Precompute keyword -> intent map for faster matching
INTENT_KEYWORDS = {}
for intent, data in KB.items():
    for token in data["prompt"]:
        token_norm = token.strip().lower()
        if token_norm:
            INTENT_KEYWORDS[token_norm] = intent

# Helpful quick bank-style suggestions (bank-helper style buttons)
QUICK_SUGGESTIONS = [
    "Timings",
    "Fees",
    "Discounts",
    "Admission process",
    "Exam schedule",
    "Attendance policy",
    "Extracurriculars",
    "Payment modes",
    "Contact staff",
    "Facilities"
]

# ======= Utility: simple keyword-based intent detector =======
def detect_intent(message: str):
    msg = message.lower()
    # direct exact keyword mapping first
    for kw, intent in INTENT_KEYWORDS.items():
        if kw in msg:
            return intent
    # fallback: regex / word token matching (looser)
    words = re.findall(r"\w+", msg)
    for w in words:
        if w in INTENT_KEYWORDS:
            return INTENT_KEYWORDS[w]
    # more advanced: look for stems
    stems = {
        "fee": "fees", "pay": "payment", "exam": "exam_schedule", "test": "exam_schedule",
        "time": "timings", "open": "timings", "close": "timings",
        "bus": "transport", "transport": "transport",
        "admit": "admission", "enroll": "admission"
    }
    for s, intent in stems.items():
        if s in msg:
            return intent
    return "default"

# ======= Routes =======
INDEX_HTML = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>School Info Chatbot</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    :root {
      --accent-1: #2b7cff;
      --accent-2: #6be7c3;
      --bg: linear-gradient(160deg,#4f9cff 0%, #7bdff5 100%);
      --card: #ffffffcc;
    }
    body { margin:0; font-family: Inter, Arial, sans-serif; background: var(--bg); height:100vh; display:flex; align-items:center; justify-content:center; }
    .app { width: 880px; max-width: 96vw; height: 640px; display: grid; grid-template-columns: 360px 1fr; gap:18px; padding:20px; }
    .left { background:var(--card); border-radius:16px; padding:18px; box-shadow:0 8px 30px rgba(0,0,0,0.12); display:flex; flex-direction:column; }
    .logo { font-weight:700; font-size:20px; color:var(--accent-1); margin-bottom:8px; }
    .desc { font-size:13px; color:#334155; margin-bottom:12px; }
    .quick { display:flex; flex-wrap:wrap; gap:8px; margin-top:auto; }
    .chip { background:#f1f9ff; border:1px solid #e6f0ff; color:var(--accent-1); padding:8px 10px; border-radius:999px; font-size:13px; cursor:pointer; }
    .right { background: rgba(255,255,255,0.95); border-radius:16px; padding:14px; display:flex; flex-direction:column; box-shadow:0 8px 30px rgba(0,0,0,0.08); }
    .header { display:flex; align-items:center; gap:12px; padding-bottom:8px; border-bottom:1px solid #eef2ff; }
    .title { font-weight:700; color:var(--accent-1); font-size:18px; }
    .chatbox { flex:1; overflow:auto; padding:12px; display:flex; flex-direction:column; gap:10px; }
    .msg { max-width:75%; padding:12px 14px; border-radius:12px; line-height:1.35; }
    .bot { background:var(--accent-1); color:white; align-self:flex-start; border-bottom-left-radius:4px; }
    .user { background:#eef6ff; color:#062b4f; align-self:flex-end; border-bottom-right-radius:4px; }
    .controls { display:flex; gap:8px; padding-top:10px; border-top:1px solid #eef2ff; margin-top:10px; }
    input[type=text] { flex:1; padding:10px 12px; border-radius:10px; border:1px solid #e6eefc; outline:none; }
    button.send { background:var(--accent-1); color:white; padding:10px 14px; border:none; border-radius:10px; cursor:pointer; }
    .suggest { display:flex; gap:8px; flex-wrap:wrap; margin-top:10px; }
    .suggest button { background:#fff; border:1px dashed #cde6ff; padding:8px 10px; border-radius:8px; cursor:pointer; }
    .small { font-size:12px; color:#6b7280; }
  </style>
</head>
<body>
  <div class="app">
    <div class="left">
      <div class="logo">MIRA MODEL SCHOOL QUICK ASSISTANCE CHATBOT
      <img src="C://Users//hp//school-chatbot//20.png"</img></div>
      <div class="desc">Fast, rule-based answers for common parent queries. Click suggestions to ask.</div>
      <div class="small">Suggested quick actions</div>
      <div class="quick" id="quick-area"></div>
      <div style="height:10px"></div>
      <div class="small">For more info visit https://www.miramodelschooldelhi.edu.in or call 011 2550 0489</div>
    </div>

    <div class="right">
      <div class="header">
        <div class="title">MAQS: MIRA ADVANCED QUERY SYSTEMS</div>
        <div style="margin-left:auto" class="small" id="greeting"></div>
      </div>

      <div class="chatbox" id="chatbox">
        <!-- messages appear here -->
      </div>

      <div class="controls">
        <input type="text" id="message" placeholder="Ask about fees, timings, admissions..." onkeydown="if(event.key==='Enter') sendMessage()" />
        <button class="send" onclick="sendMessage()">Send</button>
      </div>

      <div class="suggest" id="suggestions"></div>
    </div>
  </div>

<script>
const QUICK = {{ quick|tojson }};
const SUGGESTIONS = ["Timings","Fees","Discounts","Admission process","Exam schedule","Attendance policy","Extracurriculars","Payment modes","Contact staff","Facilities"];

function addQuickChips(){
  const q = document.getElementById('quick-area');
  QUICK.forEach(t=>{
    const el = document.createElement('div');
    el.className = 'chip';
    el.innerText = t;
    el.onclick = ()=> { setMessageAndSend(t); };
    q.appendChild(el);
  });
}
function addSuggestButtons(){
  const s = document.getElementById('suggestions');
  SUGGESTIONS.forEach(t=>{
    const b = document.createElement('button');
    b.innerText = t;
    b.onclick = ()=> setMessageAndSend(t);
    s.appendChild(b);
  });
}

function setMessageAndSend(txt){
  document.getElementById('message').value = txt;
  sendMessage();
}

function showMessage(text, who='bot'){
  const c = document.getElementById('chatbox');
  const d = document.createElement('div');
  d.className = 'msg ' + (who === 'bot' ? 'bot' : 'user');
  d.innerText = text;
  c.appendChild(d);
  c.scrollTop = c.scrollHeight;
}

function clientGreeting(){
  const h = new Date().getHours();
  const greet = h < 12 ? 'Good morning!' : (h < 17 ? 'Good afternoon!' : 'Good evening!');
  document.getElementById('greeting').innerText = greet;
  // also send an intro bot message
  showMessage(greet + " I'm the School Info Assistant — ask me about fees, timings, admissions and more.");
  showMessage("You can try quick prompts below or type your question. (Examples: 'What are school timings?', 'Sibling discount', 'Exam schedule')", 'bot');
}

async function sendMessage(){
  const inp = document.getElementById('message');
  const text = inp.value.trim();
  if(!text) return;
  showMessage(text, 'user');
  inp.value = '';
  try{
    const res = await fetch('/chat', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({message: text})
    });
    const data = await res.json();
    // display assistant reply(s)
    if(data.replies){
      for(const r of data.replies){
        showMessage(r, 'bot');
      }
    } else {
      showMessage(data.reply || "Sorry, I couldn't find that info.", 'bot');
    }
    // show suggested quick replies (if any)
    if(data.suggest && data.suggest.length){
      const s = document.getElementById('suggestions');
      s.innerHTML = '';
      data.suggest.forEach(label=>{
        const b = document.createElement('button');
        b.innerText = label;
        b.onclick = ()=> setMessageAndSend(label);
        s.appendChild(b);
      });
    }
  }catch(err){
    showMessage("Network error. Please try again.", 'bot');
    console.error(err);
  }
}

// init
addQuickChips();
addSuggestButtons();
clientGreeting();
</script>
</body>
</html>
"""

@app.route("/")
def index():
    # Render the HTML template string with quick suggestions
    return render_template_string(INDEX_HTML, quick=QUICK_SUGGESTIONS)

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json() or {}
    msg = (data.get("message") or "").strip()
    if not msg:
        return jsonify({"reply": "Please type a question or choose a suggestion."})

    intent = detect_intent(msg)
    kb_entry = KB.get(intent, KB["default"])

    # kb_entry['reply'] may be string or callable (adaptive greeting)
    reply_obj = kb_entry["reply"]
    reply_text = reply_obj() if callable(reply_obj) else reply_obj

    # Create bank-helper style additional replies / clarifications
    additional = []
    if intent == "fees":
        additional = [
            "Would you like a fee breakdown (tuition / activity / transport)?",
            "Need to download invoice or see payment history?"
        ]
    elif intent == "admission":
        additional = [
            "Want the admission form link?",
            "Would you like available seat count by grade?"
        ]
    elif intent == "exam_schedule":
        additional = [
            "I can email the full term calendar or show the dates for a specific class.",
            "Which class/grade's exam schedule would you like?"
        ]
    elif intent == "default":
        additional = [
            "Try: 'Timings', 'Fees', 'Admission', 'Exam schedule', 'Staff info'.",
            "Or type 'help' to see more suggestions."
        ]
    

    # Build response payload with a main reply and quick suggestions
    payload = {
        "intent": intent,
        "replies": [reply_text] + additional[:2],
        "suggest": QUICK_SUGGESTIONS
    }
    return jsonify(payload)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
